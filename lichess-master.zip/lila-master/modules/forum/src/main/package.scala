package lila.forum

export lila.core.lilaism.Lilaism.{ *, given }
export lila.common.extensions.*
export lila.core.id.{ ForumCategId, ForumTopicId }

private val logger = lila.log("forum")
