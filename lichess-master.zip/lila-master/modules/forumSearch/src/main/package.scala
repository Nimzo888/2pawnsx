package lila.forumSearch

export lila.core.lilaism.Lilaism.{ *, given }

private val logger = lila.log("forumSearch")

val index = lila.search.Index.Forum
