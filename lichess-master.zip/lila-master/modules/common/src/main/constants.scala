package lila.common

object constants:

  val bannedYoutubeIds = List(
    "7UpltimWY_E",
    "J_bzfjZZnjU",
    "xRiQe_tq7h0",
    "8IlVvluRbwk",
    "P3o0hPjrxgo",
    "d8TSD4f89i8",
    "b-WYer6Mjh0",
    "0GfVOMBIuLo",
    "g-DKTxYFkRQ",
    "Z5eWjccV7D0",
    "i3BT785qTWw",
    "K_Bn2phvLro",
    "V11ZQyAhEAM",
    "i3BT785qTWw",
    "ogavmoKE04Y",
    "JPim0DiXNHk",
    "roMv8RjhAQU",
    "8JdXqxGwtJU"
  )
